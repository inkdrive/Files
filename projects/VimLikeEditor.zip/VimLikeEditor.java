import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class VimLikeEditor extends JFrame {

    enum Mode {
        NORMAL,
        INSERT,
        COMMAND
    }

    private final JTextArea textArea = new JTextArea();
    private final JLabel statusBar = new JLabel();
    private final StringBuilder commandBuffer = new StringBuilder();

    private Mode currentMode = Mode.NORMAL;
    private File currentFile = null;

    public VimLikeEditor() {
        setTitle("VimLikeEditor UwU");
        setSize(1100, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setupEditor();
        setupKeyHandling();
        updateStatusBar();

        setVisible(true);
    }

    private void setupEditor() {
        setLayout(new BorderLayout());

        textArea.setFont(new Font("Consolas", Font.PLAIN, 18));
        textArea.setBackground(new Color(18, 18, 18));
        textArea.setForeground(new Color(220, 220, 220));
        textArea.setCaretColor(Color.WHITE);
        textArea.setTabSize(4);
        textArea.setBorder(new EmptyBorder(10, 10, 10, 10));
        textArea.setLineWrap(false);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(null);

        statusBar.setOpaque(true);
        statusBar.setBackground(new Color(40, 40, 40));
        statusBar.setForeground(Color.WHITE);
        statusBar.setFont(new Font("Consolas", Font.BOLD, 15));
        statusBar.setBorder(new EmptyBorder(6, 10, 6, 10));

        add(scrollPane, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);
    }

    private void setupKeyHandling() {
        textArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {

                if (currentMode == Mode.INSERT) {
                    handleInsertMode(e);
                } else if (currentMode == Mode.NORMAL) {
                    handleNormalMode(e);
                } else if (currentMode == Mode.COMMAND) {
                    handleCommandMode(e);
                }
            }
        });
    }

    // =========================================
    // INSERT MODE
    // =========================================

    private void handleInsertMode(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            currentMode = Mode.NORMAL;
            updateStatusBar();
            e.consume();
        }
    }

    // =========================================
    // NORMAL MODE
    // =========================================

    private void handleNormalMode(KeyEvent e) {
        e.consume();

        switch (e.getKeyCode()) {
            case KeyEvent.VK_I -> {
                currentMode = Mode.INSERT;
                updateStatusBar();
            }

            case KeyEvent.VK_H -> moveCaret(-1);
            case KeyEvent.VK_L -> moveCaret(1);
            case KeyEvent.VK_J -> moveVertical(1);
            case KeyEvent.VK_K -> moveVertical(-1);

            case KeyEvent.VK_X -> deleteCharacter();

            case KeyEvent.VK_O -> openNewLineBelow();

            case KeyEvent.VK_COLON -> {
                currentMode = Mode.COMMAND;
                commandBuffer.setLength(0);
                updateStatusBar();
            }
        }
    }

    // =========================================
    // COMMAND MODE
    // =========================================

    private void handleCommandMode(KeyEvent e) {
        e.consume();

        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            currentMode = Mode.NORMAL;
            commandBuffer.setLength(0);
            updateStatusBar();
            return;
        }

        if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
            if (!commandBuffer.isEmpty()) {
                commandBuffer.deleteCharAt(commandBuffer.length() - 1);
            }
            updateStatusBar();
            return;
        }

        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            executeCommand(commandBuffer.toString());
            commandBuffer.setLength(0);
            currentMode = Mode.NORMAL;
            updateStatusBar();
            return;
        }

        char ch = e.getKeyChar();

        if (!Character.isISOControl(ch)) {
            commandBuffer.append(ch);
            updateStatusBar();
        }
    }

    // =========================================
    // COMMANDS
    // =========================================

    private void executeCommand(String command) {
        switch (command) {
            case "w" -> saveFile();
            case "q" -> dispose();
            case "wq" -> {
                saveFile();
                dispose();
            }
            case "open" -> openFile();
            default -> JOptionPane.showMessageDialog(this,
                    "Unknown command: :" + command);
        }
    }

    // =========================================
    // MOVEMENT
    // =========================================

    private void moveCaret(int amount) {
        int pos = textArea.getCaretPosition();
        int newPos = Math.max(0,
                Math.min(textArea.getText().length(), pos + amount));

        textArea.setCaretPosition(newPos);
    }

    private void moveVertical(int direction) {
        try {
            int caret = textArea.getCaretPosition();
            int line = textArea.getLineOfOffset(caret);
            int column = caret - textArea.getLineStartOffset(line);

            int targetLine = line + direction;

            if (targetLine < 0 || targetLine >= textArea.getLineCount()) {
                return;
            }

            int targetStart = textArea.getLineStartOffset(targetLine);
            int targetEnd = textArea.getLineEndOffset(targetLine);

            int targetPos = Math.min(targetStart + column, targetEnd - 1);
            textArea.setCaretPosition(targetPos);

        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }

    // =========================================
    // EDITING
    // =========================================

    private void deleteCharacter() {
        int pos = textArea.getCaretPosition();

        if (pos < textArea.getText().length()) {
            textArea.replaceRange("", pos, pos + 1);
        }
    }

    private void openNewLineBelow() {
        try {
            int caret = textArea.getCaretPosition();
            int line = textArea.getLineOfOffset(caret);
            int end = textArea.getLineEndOffset(line);

            textArea.insert("\n", end - 1);
            textArea.setCaretPosition(end);

            currentMode = Mode.INSERT;
            updateStatusBar();

        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }
    }

    // =========================================
    // FILES
    // =========================================

    private void saveFile() {
        try {
            if (currentFile == null) {
                JFileChooser chooser = new JFileChooser();

                int result = chooser.showSaveDialog(this);

                if (result != JFileChooser.APPROVE_OPTION) {
                    return;
                }

                currentFile = chooser.getSelectedFile();
            }

            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(currentFile)
            );

            writer.write(textArea.getText());
            writer.close();

            JOptionPane.showMessageDialog(this,
                    "Saved: " + currentFile.getName());

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void openFile() {
        try {
            JFileChooser chooser = new JFileChooser();

            int result = chooser.showOpenDialog(this);

            if (result != JFileChooser.APPROVE_OPTION) {
                return;
            }

            currentFile = chooser.getSelectedFile();

            BufferedReader reader = new BufferedReader(
                    new FileReader(currentFile)
            );

            StringBuilder content = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }

            reader.close();

            textArea.setText(content.toString());
            textArea.setCaretPosition(0);

            JOptionPane.showMessageDialog(this,
                    "Opened: " + currentFile.getName());

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // =========================================
    // STATUS BAR
    // =========================================

    private void updateStatusBar() {
        switch (currentMode) {
            case NORMAL -> statusBar.setText(" NORMAL MODE | i = insert | hjkl = move | : = command ");

            case INSERT -> statusBar.setText(" INSERT MODE | ESC = normal mode ");

            case COMMAND -> statusBar.setText(" COMMAND MODE | :" + commandBuffer);
        }
    }

    // =========================================
    // MAIN
    // =========================================

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VimLikeEditor::new);
    }
}
