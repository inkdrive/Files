
import UIComponent.BasicComponent.BlueButtonUI;
import UIComponent.BasicComponent.GreenButtonUI;
import UIComponent.MeshMaps.HashCode;
import UIComponent.MeshMaps.HashHandler;
import UIComponent.MeshMaps.MeshMap2D;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {

        JFrame frame = new JFrame("MeshMap Stage 2");

        frame.setSize(900,900);

        frame.setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        // ===================================
        // CANVAS
        // ===================================

        Canvas canvas = new Canvas();

        // ===================================
        // HASH CODES
        // ===================================

        HashCode blue =
                new HashCode(
                        1,
                        new BlueButtonUI()
                );

        HashCode green =
                new HashCode(
                        2,
                        new GreenButtonUI()
                );

        // ===================================
        // HASH HANDLER
        // ===================================

        HashHandler handler =
                new HashHandler(
                        blue,
                        green
                );

        // ===================================
        // MESHMAP
        // ===================================

        MeshMap2D mesh =
                new MeshMap2D(
                        4,
                        4,
                        800,
                        800,
                        handler
                );

        // ===================================
        // MAP
        // ===================================

        mesh.map = new int[][]{

                {1,0,1,0},
                {0,2,0,1},
                {1,1,2,1},
                {0,0,1,2}
        };

        // ===================================
        // IRREGULAR GRID
        // ===================================

        mesh.columns(
                1,
                1,
                1,
                1
        );

        mesh.rows(
                1,
                1,
                1,
                1
        );

        // ===================================
        // BUILD
        // ===================================

        mesh.buildLayout();

        // ===================================
        // ADD TO CANVAS
        // ===================================

        canvas.addComponent(mesh);

        frame.add(canvas);

        frame.setVisible(true);
    }
}