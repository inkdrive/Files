package Interfaces;

import Utility.DimensionFX;

public interface isRounded {
    public void setRounded(DimensionFX d);
}
