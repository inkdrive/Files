package Utility.Input;

public class FocusState {
}
