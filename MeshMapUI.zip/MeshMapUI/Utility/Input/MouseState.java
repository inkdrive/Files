package Utility.Input;

public class MouseState {

    public int x;
    public int y;

    public boolean pressed;

    public boolean dragging;

    public MouseState(){

        x = 0;
        y = 0;

        pressed = false;
        dragging = false;
    }
}