package Utility.Input;

import UIComponent.UIComponent;

import java.util.ArrayList;

public class InputManager {

    // =====================================
    // MOUSE
    // =====================================

    public MouseState mouse =
            new MouseState();

    // =====================================
    // COMPONENTS
    // =====================================

    ArrayList<UIComponent>
            roots;

    // =====================================
    // STATES
    // =====================================

    UIComponent hovered;

    UIComponent focused;

    UIComponent pressedComponent;

    // =====================================
    // CONSTRUCTOR
    // =====================================

    public InputManager(
            ArrayList<UIComponent>
                    roots
    ){

        this.roots = roots;
    }

    // =====================================
    // MOUSE MOVE
    // =====================================

    public void mouseMoved(
            int mx,
            int my
    ){

        mouse.x = mx;
        mouse.y = my;

        hovered = findTopComponent(
                mx,
                my
        );

        if(hovered != null){

            hovered.mouseMoved(
                    mx,
                    my
            );
        }
    }

    // =====================================
    // MOUSE PRESS
    // =====================================

    public void mousePressed(
            int mx,
            int my
    ){

        mouse.pressed = true;

        mouse.x = mx;
        mouse.y = my;

        pressedComponent =
                findTopComponent(
                        mx,
                        my
                );

        focused =
                pressedComponent;

        if(pressedComponent != null){

            pressedComponent.mousePressed(
                    mx,
                    my
            );
        }
    }

    // =====================================
    // MOUSE RELEASE
    // =====================================

    public void mouseReleased(
            int mx,
            int my
    ){

        mouse.pressed = false;

        mouse.dragging = false;

        mouse.x = mx;
        mouse.y = my;

        if(pressedComponent != null){

            pressedComponent.mouseReleased(
                    mx,
                    my
            );
        }

        pressedComponent = null;
    }

    // =====================================
    // MOUSE DRAGGED
    // =====================================

    public void mouseDragged(
            int mx,
            int my
    ){

        mouse.dragging = true;

        mouse.x = mx;
        mouse.y = my;

        if(pressedComponent != null){

            pressedComponent.mouseDragged(
                    mx,
                    my
            );
        }
    }

    // =====================================
    // FIND TOP COMPONENT
    // =====================================

    public UIComponent findTopComponent(
            int mx,
            int my
    ){

        UIComponent found = null;

        int highestLayer =
                Integer.MIN_VALUE;

        for(UIComponent ui
                : roots){

            UIComponent hit =
                    findRecursive(
                            ui,
                            mx,
                            my
                    );

            if(hit != null){

                if(hit.getLayer()
                        >= highestLayer){

                    highestLayer =
                            hit.getLayer();

                    found = hit;
                }
            }
        }

        return found;
    }

    // =====================================
    // RECURSIVE SEARCH
    // =====================================

    private UIComponent findRecursive(
            UIComponent ui,
            int mx,
            int my
    ){

        if(!ui.isVisible()){

            return null;
        }

        // =====================================
        // CHECK CHILDREN FIRST
        // =====================================

        for(UIComponent child
                : ui.getChildren()){

            UIComponent found =
                    findRecursive(
                            child,
                            mx -
                                    ui.getLocation().getX(),

                            my -
                                    ui.getLocation().getY()
                    );

            if(found != null){

                return found;
            }
        }

        // =====================================
        // CHECK SELF
        // =====================================

        if(ui.containsPoint(mx,my)){

            return ui;
        }

        return null;
    }

    // =====================================
    // GETTERS
    // =====================================

    public UIComponent getFocused(){

        return focused;
    }

    public UIComponent getHovered(){

        return hovered;
    }
}