package Utility;

public class DimensionFX {
    int X , Y;


    public DimensionFX(int a, int b){
        this.X = a ;
        this.Y = b ;
    }
    public int getX(){
        return X;
    }
    public int getY(){
        return Y;
    }
    public void setX(int a){
        X = a;
    }
    public void setY(int b){
        Y = b;
    }
}
