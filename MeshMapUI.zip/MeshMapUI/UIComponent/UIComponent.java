package UIComponent;

import Utility.DimensionFX;

import java.awt.*;
import java.util.ArrayList;

public abstract class UIComponent {

    protected DimensionFX location =
            new DimensionFX(0,0);

    protected DimensionFX size =
            new DimensionFX(0,0);

    protected Insets padding =
            new Insets(0,0,0,0);

    protected Insets margin =
            new Insets(0,0,0,0);

    protected int layer = 0;

    protected boolean visible = true;

    protected boolean hovered = false;
    protected boolean pressed = false;
    protected boolean focused = false;

    protected ArrayList<UIComponent>
            children =
            new ArrayList<>();

    // =========================
    // spatial
    // =========================

    public void setLocation(
            DimensionFX location
    ){

        this.location = location;
    }

    public void setSize(
            DimensionFX size
    ){

        this.size = size;
    }

    public DimensionFX getLocation(){

        return location;
    }

    public DimensionFX getSize(){

        return size;
    }

    // =========================
    // spacing
    // =========================

    public void setPadding(
            Insets padding
    ){

        this.padding = padding;
    }

    public Insets getPadding(){

        return padding;
    }

    public void setMargin(
            Insets margin
    ){

        this.margin = margin;
    }

    public Insets getMargin(){

        return margin;
    }

    // =========================
    // state
    // =========================

    public void setLayer(
            int layer
    ){

        this.layer = layer;
    }

    public int getLayer(){

        return layer;
    }

    public void setVisible(
            boolean visible
    ){

        this.visible = visible;
    }

    public boolean isVisible(){

        return visible;
    }

    // =========================
    // children
    // =========================

    public void add(
            UIComponent ui
    ){

        children.add(ui);
    }

    public ArrayList<UIComponent>
    getChildren(){

        return children;
    }

    // =========================
    // hit test
    // =========================

    public boolean containsPoint(
            int mx,
            int my
    ){

        return
                mx >= 0
                        &&
                        mx <= size.getX()
                        &&
                        my >= 0
                        &&
                        my <= size.getY();
    }

    // =========================
    // render tree
    // =========================

    public void drawTree(
            Graphics g
    ){

        if(!visible){

            return;
        }

        Graphics2D g2 =
                (Graphics2D) g.create();

        g2.translate(
                location.getX()
                        + margin.left,

                location.getY()
                        + margin.top
        );

        draw(g2);

        g2.translate(
                padding.left,
                padding.top
        );

        for(UIComponent child
                : children){

            child.drawTree(g2);
        }

        g2.dispose();
    }

    // =========================
    // input tree
    // =========================

    public void mouseMovedTree(
            int mx,
            int my
    ){

        int rx =
                mx
                        - location.getX()
                        - margin.left;

        int ry =
                my
                        - location.getY()
                        - margin.top;

        hovered =
                containsPoint(rx,ry);

        mouseMoved(rx,ry);

        rx -= padding.left;
        ry -= padding.top;

        for(UIComponent child
                : children){

            child.mouseMovedTree(
                    rx,
                    ry
            );
        }
    }

    public void mousePressedTree(
            int mx,
            int my
    ){

        int rx =
                mx
                        - location.getX()
                        - margin.left;

        int ry =
                my
                        - location.getY()
                        - margin.top;

        if(containsPoint(rx,ry)){

            pressed = true;
            focused = true;

            mousePressed(rx,ry);
        }

        rx -= padding.left;
        ry -= padding.top;

        for(UIComponent child
                : children){

            child.mousePressedTree(
                    rx,
                    ry
            );
        }
    }

    public void mouseReleasedTree(
            int mx,
            int my
    ){

        int rx =
                mx
                        - location.getX()
                        - margin.left;

        int ry =
                my
                        - location.getY()
                        - margin.top;

        pressed = false;

        mouseReleased(rx,ry);

        rx -= padding.left;
        ry -= padding.top;

        for(UIComponent child
                : children){

            child.mouseReleasedTree(
                    rx,
                    ry
            );
        }
    }

    public void mouseDraggedTree(
            int mx,
            int my
    ){

        int rx =
                mx
                        - location.getX()
                        - margin.left;

        int ry =
                my
                        - location.getY()
                        - margin.top;

        mouseDragged(rx,ry);

        rx -= padding.left;
        ry -= padding.top;

        for(UIComponent child
                : children){

            child.mouseDraggedTree(
                    rx,
                    ry
            );
        }
    }

    // =========================
    // hooks
    // =========================

    public void mouseMoved(
            int mx,
            int my
    ){

    }

    public void mousePressed(
            int mx,
            int my
    ){

    }

    public void mouseReleased(
            int mx,
            int my
    ){

    }

    public void mouseDragged(
            int mx,
            int my
    ){

    }

    // =========================
    // abstract
    // =========================

    public abstract void draw(
            Graphics g
    );

    public abstract UIComponent
    cloneComponent();
}