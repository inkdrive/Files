package UIComponent.BasicComponent;

import UIComponent.UIComponent;
import Utility.DimensionFX;

import java.awt.*;

public class PanelUI extends UIComponent {

    // =====================================
    // COLORS
    // =====================================

    protected Color background =
            new Color(45,45,45);

    protected Color borderColor =
            new Color(255,255,255,40);

    // =====================================
    // ROUNDED CORNERS
    // =====================================

    protected DimensionFX curvature =
            new DimensionFX(20,20);

    // =====================================
    // SETTERS
    // =====================================

    public void setBackgroundColor(
            Color color
    ){

        this.background = color;
    }

    public void setBorderColor(
            Color color
    ){

        this.borderColor = color;
    }

    public void setCurvature(
            DimensionFX curvature
    ){

        this.curvature = curvature;
    }

    // =====================================
    // DRAW
    // =====================================

    @Override
    public void draw(Graphics g) {

        Graphics2D g2 =
                (Graphics2D) g;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        int x = 0;
        int y = 0;

        int w = size.getX();
        int h = size.getY();

        int arcW = curvature.getX();
        int arcH = curvature.getY();

        // =====================================
        // SHADOW
        // =====================================

        g2.setColor(
                new Color(0,0,0,40)
        );

        g2.fillRoundRect(
                5,
                5,
                w,
                h,
                arcW,
                arcH
        );

        // =====================================
        // BACKGROUND
        // =====================================

        GradientPaint gradient =
                new GradientPaint(
                        0,
                        0,
                        background.brighter(),

                        0,
                        h,

                        background.darker()
                );

        g2.setPaint(gradient);

        g2.fillRoundRect(
                x,
                y,
                w,
                h,
                arcW,
                arcH
        );

        // =====================================
        // BORDER
        // =====================================

        g2.setColor(borderColor);

        g2.drawRoundRect(
                x,
                y,
                w,
                h,
                arcW,
                arcH
        );
    }

    // =====================================
    // CLONE
    // =====================================

    @Override
    public UIComponent cloneComponent() {

        PanelUI p =
                new PanelUI();

        p.setSize(
                new DimensionFX(
                        size.getX(),
                        size.getY()
                )
        );

        p.setCurvature(
                new DimensionFX(
                        curvature.getX(),
                        curvature.getY()
                )
        );

        p.setPadding(
                new Insets(
                        padding.top,
                        padding.left,
                        padding.bottom,
                        padding.right
                )
        );

        p.setMargin(
                new Insets(
                        margin.top,
                        margin.left,
                        margin.bottom,
                        margin.right
                )
        );

        p.setBackgroundColor(
                background
        );

        p.setBorderColor(
                borderColor
        );

        return p;
    }
}
