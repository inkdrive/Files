package UIComponent.BasicComponent;

import UIComponent.UIComponent;
import Utility.DimensionFX;

import java.awt.*;

public class GreenButtonUI extends ButtonUI {

    public GreenButtonUI(){

        setRounded(
                new DimensionFX(30,30)
        );

        setSize(
                new DimensionFX(50,50)
        );

        setText("+");

        normalTop =
                new Color(137,244,148);

        normalBottom =
                new Color(186,251,152);

        hoverTop =
                new Color(94,133,205);

        hoverBottom =
                new Color(73,109,234);

        textColor =
                Color.BLACK;
    }

    @Override
    public UIComponent cloneComponent(){

        return new GreenButtonUI();
    }
}