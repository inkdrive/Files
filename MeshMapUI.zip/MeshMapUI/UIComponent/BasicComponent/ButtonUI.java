package UIComponent.BasicComponent;

import Interfaces.isRounded;
import UIComponent.UIComponent;
import Utility.DimensionFX;

import java.awt.*;

public abstract class ButtonUI
        extends UIComponent
        implements isRounded {

    protected DimensionFX curvature;

    protected boolean hovered = false;

    protected String text = "Button";

    protected Color normalTop;

    protected Color normalBottom;

    protected Color hoverTop;

    protected Color hoverBottom;

    protected Color textColor = Color.WHITE;

    public void setText(String text){

        this.text = text;
    }

    @Override
    public void setRounded(DimensionFX d){

        curvature = d;
    }

    @Override
    public void mouseMoved(int mx, int my){

        int x = location.getX();
        int y = location.getY();

        int w = size.getX();
        int h = size.getY();

        hovered =
                mx >= x &&
                        mx <= x + w &&
                        my >= y &&
                        my <= y + h;
    }

    @Override
    public void draw(Graphics g){

        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        int x = location.getX();
        int y = location.getY();

        int w = size.getX();
        int h = size.getY();

        int arcW = curvature.getX();
        int arcH = curvature.getY();

        Color top;
        Color bottom;

        if(hovered){

            top = hoverTop;
            bottom = hoverBottom;

        } else {

            top = normalTop;
            bottom = normalBottom;
        }

        // Shadow

        g2.setColor(
                new Color(0,0,0,35)
        );

        g2.fillRoundRect(
                x + 4,
                y + 4,
                w,
                h,
                arcW,
                arcH
        );

        // Gradient

        GradientPaint gradient =
                new GradientPaint(
                        x,
                        y,
                        top,
                        x,
                        y + h,
                        bottom
                );

        g2.setPaint(gradient);

        g2.fillRoundRect(
                x,
                y,
                w,
                h,
                arcW,
                arcH
        );

        // Border

        g2.setColor(
                new Color(255,255,255,90)
        );

        g2.drawRoundRect(
                x,
                y,
                w,
                h,
                arcW,
                arcH
        );

        // Text

        g2.setColor(textColor);

        Font font =
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                );

        g2.setFont(font);

        FontMetrics fm =
                g2.getFontMetrics();

        int textWidth =
                fm.stringWidth(text);

        int textHeight =
                fm.getAscent();

        int tx =
                x + (w - textWidth)/2;

        int ty =
                y + (h + textHeight)/2 - 4;

        g2.drawString(
                text,
                tx,
                ty
        );
    }
}