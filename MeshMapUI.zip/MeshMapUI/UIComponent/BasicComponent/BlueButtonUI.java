package UIComponent.BasicComponent;

import UIComponent.UIComponent;
import Utility.DimensionFX;

import java.awt.*;

public class BlueButtonUI extends ButtonUI {

    public BlueButtonUI(){

        setRounded(
                new DimensionFX(20,20)
        );

        setSize(
                new DimensionFX(80,80)
        );

        setText("Blue");

        normalTop =
                new Color(90,130,255);

        normalBottom =
                new Color(40,70,220);

        hoverTop =
                new Color(140,180,255);

        hoverBottom =
                new Color(70,110,255);
    }

    @Override
    public UIComponent cloneComponent(){

        return new BlueButtonUI();
    }
}