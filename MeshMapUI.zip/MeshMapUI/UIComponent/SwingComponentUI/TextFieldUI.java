package UIComponent.SwingComponentUI;

import javax.swing.*;

public class TextFieldUI
        extends SwingComponentUI {

    public TextFieldUI(){

        super(
                new JTextField()
        );

        component.setSize(180,40);
    }

    public JTextField getTextField(){

        return (JTextField) component;
    }

    @Override
    public TextFieldUI cloneComponent(){

        return new TextFieldUI();
    }
}