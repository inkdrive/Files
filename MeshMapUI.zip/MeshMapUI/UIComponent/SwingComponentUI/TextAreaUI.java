package UIComponent.SwingComponentUI;

import javax.swing.*;

public class TextAreaUI
        extends SwingComponentUI {

    public TextAreaUI(){

        super(
                new JTextArea()
        );

        component.setSize(250,120);
    }

    public JTextArea getTextArea(){

        return (JTextArea) component;
    }

    @Override
    public TextAreaUI cloneComponent(){

        return new TextAreaUI();
    }
}