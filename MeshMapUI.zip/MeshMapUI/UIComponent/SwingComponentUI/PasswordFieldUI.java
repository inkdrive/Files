package UIComponent.SwingComponentUI;

import javax.swing.*;

public class PasswordFieldUI
        extends SwingComponentUI {

    public PasswordFieldUI(){

        super(
                new JPasswordField()
        );

        component.setSize(180,40);
    }

    public JPasswordField getPasswordField(){

        return (JPasswordField) component;
    }

    @Override
    public PasswordFieldUI cloneComponent(){

        return new PasswordFieldUI();
    }
}