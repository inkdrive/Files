package UIComponent.SwingComponentUI;

import UIComponent.UIComponent;
import Utility.DimensionFX;

import javax.swing.*;
import java.awt.*;

public abstract class SwingComponentUI
        extends UIComponent {

    protected JComponent component;

    public SwingComponentUI(
            JComponent component
    ){

        this.component = component;
    }

    public JComponent getComponent(){

        return component;
    }

    @Override
    public void setLocation(
            DimensionFX location
    ){

        super.setLocation(location);

        component.setLocation(
                location.getX(),
                location.getY()
        );
    }

    @Override
    public void setSize(
            DimensionFX size
    ){

        super.setSize(size);

        component.setSize(
                size.getX(),
                size.getY()
        );
    }

    @Override
    public void draw(Graphics g){

        // Swing draws itself
    }
}