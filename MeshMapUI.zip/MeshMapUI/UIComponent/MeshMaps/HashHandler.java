package UIComponent.MeshMaps;

public class HashHandler {

    public HashCode[] cache;

    public HashHandler(HashCode... hashes){

        cache = hashes;
    }
}