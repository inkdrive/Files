package UIComponent.MeshMaps;

import UIComponent.UIComponent;
import Utility.DimensionFX;

import java.awt.*;

public class MeshMap2D extends UIComponent {

    public int[][] map;

    int rows;
    int cols;

    int totalWidth;
    int totalHeight;

    HashHandler hash;

    UIComponent[][] builtComponents;

    // NEW

    int[] columnWeights;
    int[] rowWeights;

    public MeshMap2D(
            int rows,
            int cols,
            int totalWidth,
            int totalHeight,
            HashHandler hash
    ) {

        this.hash = hash;

        this.rows = rows;
        this.cols = cols;

        this.totalWidth = totalWidth;
        this.totalHeight = totalHeight;

        map = new int[rows][cols];

        builtComponents = new UIComponent[rows][cols];

        // DEFAULT WEIGHTS

        columnWeights = new int[cols];
        rowWeights = new int[rows];

        for (int i = 0; i < cols; i++) {

            columnWeights[i] = 1;
        }

        for (int i = 0; i < rows; i++) {

            rowWeights[i] = 1;
        }
    }

    // ===================================
    // COLUMN WEIGHTS
    // ===================================

    public void columns(int... weights) {

        if (weights.length != cols) {

            System.out.println(
                    "COLUMN WEIGHT ERROR"
            );

            return;
        }

        columnWeights = weights;
    }

    // ===================================
    // ROW WEIGHTS
    // ===================================

    public void rows(int... weights) {

        if (weights.length != rows) {

            System.out.println(
                    "ROW WEIGHT ERROR"
            );

            return;
        }

        rowWeights = weights;
    }

    // ===================================
    // BUILD LAYOUT
    // ===================================

    public void buildLayout() {

        int totalColumnWeight = 0;

        for (int w : columnWeights) {

            totalColumnWeight += w;
        }

        int totalRowWeight = 0;

        for (int h : rowWeights) {

            totalRowWeight += h;
        }

        for (int i = 0; i < rows; i++) {

            for (int j = 0; j < cols; j++) {

                int id = map[i][j];

                for (HashCode hc : hash.cache) {

                    if (hc.id == id) {

                        UIComponent component =
                                hc.createComponent();

                        // =========================
                        // CALCULATE CELL WIDTH
                        // =========================

                        int currentCellWidth =
                                (totalWidth * columnWeights[j])
                                        / totalColumnWeight;

                        // =========================
                        // CALCULATE CELL HEIGHT
                        // =========================

                        int currentCellHeight =
                                (totalHeight * rowWeights[i])
                                        / totalRowWeight;

                        // =========================
                        // CALCULATE X POSITION
                        // =========================

                        int currentX = 0;

                        for (int k = 0; k < j; k++) {

                            currentX +=
                                    (totalWidth * columnWeights[k])
                                            / totalColumnWeight;
                        }

                        // =========================
                        // CALCULATE Y POSITION
                        // =========================

                        int currentY = 0;

                        for (int k = 0; k < i; k++) {

                            currentY +=
                                    (totalHeight * rowWeights[k])
                                            / totalRowWeight;
                        }

                        // =========================
                        // CENTER COMPONENT
                        // =========================

                        int x = currentX +
                                (currentCellWidth
                                        - component.getSize().getX()) / 2;

                        int y = currentY +
                                (currentCellHeight
                                        - component.getSize().getY()) / 2;

                        component.setLocation(
                                new DimensionFX(x, y)
                        );

                        builtComponents[i][j] = component;
                    }
                }
            }
        }
    }

    // ===================================
    // DRAW
    // ===================================

    @Override
    public void draw(Graphics g) {

        for (int i = 0; i < rows; i++) {

            for (int j = 0; j < cols; j++) {

                UIComponent component =
                        builtComponents[i][j];

                if (component != null) {

                    component.drawTree(g);
                }
            }
        }
    }

    // ===================================
    // MOUSE EVENTS
    // ===================================

    @Override
    public void mouseMoved(
            int mx,
            int my
    ) {

        for (int i = 0; i < rows; i++) {

            for (int j = 0; j < cols; j++) {

                UIComponent component =
                        builtComponents[i][j];

                if (component != null) {

                    component.mouseMoved(
                            mx,
                            my
                    );
                }
            }
        }
    }


    @Override
    public UIComponent cloneComponent() {
        return null;
    }
}