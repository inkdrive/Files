package UIComponent.MeshMaps;

import UIComponent.UIComponent;

public class HashCode {

    public int id;

    public UIComponent prototype;

    public HashCode(
            int id,
            UIComponent prototype
    ){

        this.id = id;

        this.prototype = prototype;
    }

    public UIComponent createComponent(){

        return prototype.cloneComponent();
    }
}