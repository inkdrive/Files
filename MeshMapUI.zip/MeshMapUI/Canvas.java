import UIComponent.SwingComponentUI.SwingComponentUI;
import UIComponent.UIComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

public class Canvas extends JPanel {

    ArrayList<UIComponent> aui = new ArrayList<>();


    public Canvas(){

        setBackground(new Color(240,240,240));

        addMouseMotionListener(new MouseMotionAdapter() {

            @Override
            public void mouseMoved(MouseEvent e) {

                for(UIComponent ui : aui){

                    ui.mouseMoved(
                            e.getX(),
                            e.getY()
                    );
                }

                repaint();
            }
        });
    }
    public void addComponent(UIComponent ui ){

        aui.add(ui);

        // ==================================
        // SWING COMPONENT SUPPORT
        // ==================================

        if(ui instanceof SwingComponentUI){

            SwingComponentUI swingUI =
                    (SwingComponentUI) ui;

            add(
                    swingUI.getComponent()
            );
        }

        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;

        for(UIComponent x : aui){

            x.drawTree(g2);
        }
    }
}